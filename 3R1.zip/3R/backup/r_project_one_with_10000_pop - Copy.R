setwd("C:\\Users\\huanglinc\\Desktop\\Project1 Statistics\\2R")
#this file is to run 

#making life table based on csv files
source("life_table.R")


#plot
#install.packages("ggplot2")
library(ggplot2)
myGraph <- ggplot(lifeTable, aes(ages, A_x))
myGraph + geom_point()

inputAges = 45
inputBenefit = 1000
nsp <- lifeTable[ages == inputAges, c("A_x")]*inputBenefit
print(nsp)


#now creating a block of 10000 people who are in diffrent ages and want diffrent benefits



#Bdataframe <- data.frame(Age=Bage,Benefit=Bben,NetSinglePremium=Bnps)
#write.csv(Bdataframe,file="BusisinessData.csv",  append = FALSE)
BussinessBlock <- function(rAge,rBenefit) { 
  netSinglePremium <- lifeTable[ages == rAge, c("A_x")]*rBenefit
  return(netSinglePremium)
}
bAge <- 0
bBen <- 0
bNps <- 0
bFAge <- 0
maxAges <- max(lifeTable$ages)
lifeTableAges <- lifeTable$ages[ages < maxAges]# avoid picking max ages
# looping 
#lifeTableAges <- data.frame(Age=ages) # creating a data frame that contains the ages 
for (i in 1:5000){ # 10,000 (whole life) incurances with Net Single Premium
  
  randomAge <-  sample(lifeTableAges, 1) 
  randomBenefit <- sample.int(9000, 1, replace=TRUE) + 1000 # picking one randonm integer from range $1000-$1000000 benefit
  bAge[i] <- randomAge # concatenate
  bBen[i] <- randomBenefit # concatenate
  bNps[i] <- BussinessBlock(randomAge,randomBenefit) # calling the function to calculate the net single premium then concatenate

  #--------calculate random dies based on mortality table ----------
  #calculate probability of (x) lives t years  t_p_x where x = inputAges
  previousAgeP <- lifeTable[ages == (randomAge - 1), c("t_p_x0")]
  if (randomAge > 0) {
    pLives <- lifeTable[ages >= randomAge, c("t_p_x0")]/previousAgeP
  } else {
    pLives <- lifeTable[ages >= randomAge, c("t_p_x0")]
  }
  
  pLivesAges <- lifeTable[ages >= randomAge, c("ages")]
  pCurveX <- data.frame(pLivesAges, pLives)
  
  #calculate probability t_1_q_x that x survives t years and dies within 1 year
  pCurveXRow <- nrow(pCurveX)
  
  #probability of dead based on input age
  for (j in 1:(pCurveXRow-1)) {
    pCurveX$t_1_q_x[j] <- pCurveX$pLives[j] - pCurveX$pLives[j+1] #i = u in the pdf   1 = t in pdf
  }
  pCurveX$t_1_q_x[pCurveXRow] <- pCurveX$pLives[pCurveXRow] # last line
  
  
  #generate random dies based on input age
  randomFinalAge <- sample(pCurveX$pLivesAges, 1, replace = T, pCurveX$t_1_q_x)
  bFAge[i] <- randomFinalAge
  
  #myGraph <- ggplot(pCurveX, aes(pLivesAges, t_1_q_x))
  #print(myGraph + geom_point() + geom_point(aes(x=randomFinalAge, y=0.02), color="red"))
  #Sys.sleep(2)
  
  
}
#hist(bBen)

bDataFrame <- data.frame(Age = bAge, Benefit = bBen, NetSinglePremium = bNps, Die = bFAge) #Creating the final dataframe
write.csv(bDataFrame,file="BusisinessData.csv",  append = FALSE) # creating the CSV file, each time we run the code new file will be created and the older file will be replaced 



#---------------

#calculate probability of (x) lives t years  t_p_x where x = inputAges
previousAgeP <- lifeTable[ages == (inputAges - 1), c("t_p_x0")]
if (inputAges > 0) {
  pLives <- lifeTable[ages >= inputAges, c("t_p_x0")]/previousAgeP
} else {
  pLives <- lifeTable[ages >= inputAges, c("t_p_x0")]
}

pLivesAges <- lifeTable[ages >= inputAges, c("ages")]
pCurveX <- data.frame(pLivesAges, pLives)

#calculate probability t_1_q_x that x survives t years and dies within 1 year
pCurveXRow <- nrow(pCurveX)

#probability of dead based on input age
for (i in 1:(pCurveXRow-1)) {
  pCurveX$t_1_q_x[i] <- pCurveX$pLives[i] - pCurveX$pLives[i+1] #i = u in the pdf   1 = t in pdf
}
pCurveX$t_1_q_x[pCurveXRow] <- pCurveX$pLives[pCurveXRow] # last line
print(sum(pCurveX$t_1_q_x))

#generate random dies based on input age
s <- sample(pCurveX$pLivesAges, 1000, replace = T, pCurveX$t_1_q_x)
ttt <- data.frame(s)
myGraph <- ggplot(ttt, aes(s))
myGraph + geom_histogram()

#plot lives probability based on input age
myGraph <- ggplot(pCurveX, aes(pLivesAges, pLives))
myGraph + geom_point()

#plot t_1_q_x based on input age
myGraph <- ggplot(pCurveX, aes(pLivesAges, t_1_q_x))
myGraph + geom_point()



endTime <- Sys.time() # calulating the ending time
totalTime <- endTime - startTime #calulating the total time
print(totalTime) # printing the total time